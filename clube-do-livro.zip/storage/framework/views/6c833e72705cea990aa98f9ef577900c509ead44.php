<div class="px-4 py-2">
    <label for="<?php echo e($name); ?>" class="block text-sm leading-5 font-medium text-gray-500">
        <?php echo e($slot); ?>

    </label>
    <div class="mt-1 relative rounded-md shadow-sm">

        <input id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" 
            type="<?php echo e($type); ?>" 
            <?php if($title ?? null): ?> title="<?php echo e($title); ?>" <?php endif; ?>
            <?php if($maxlength ?? null): ?> maxlength="<?php echo e($maxlength); ?>" <?php endif; ?> 
            <?php if($pattern ?? null): ?> pattern="<?php echo e($pattern); ?>" <?php endif; ?> 
            <?php if($value ?? null): ?> value="<?php echo e(old($name, $value)); ?>" <?php else: ?> value="<?php echo e(old($name)); ?>" <?php endif; ?>
            <?php if($disabled ?? null): ?> disabled <?php endif; ?>
            <?php if($step ?? null): ?> step="<?php echo e($step); ?>" <?php endif; ?>
            <?php if($min ?? null): ?> min="<?php echo e($min); ?>" <?php endif; ?>
            <?php if($max ?? null): ?> max="<?php echo e($max); ?>" <?php endif; ?>
                
            <?php if($errors->has($name)): ?>
                <?php echo e($attributes->merge(['class' => 'form-input block w-full pr-12 sm:text-sm sm:leading-5 border-red-500'])); ?>

            <?php else: ?>
                <?php echo e($attributes->merge(['class' => 'form-input block w-full pr-12 sm:text-sm sm:leading-5'])); ?>

            <?php endif; ?>
        />

        <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small role="alert" class="text-red-500 text-xs"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>
</div><?php /**PATH C:\wamp64\www\clube-do-livro\resources\views/components/input.blade.php ENDPATH**/ ?>