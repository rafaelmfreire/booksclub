<?php $__env->startSection('content'); ?>
    <div class="flex items-center">
        <div class="md:w-1/2 md:mx-auto pt-6">

            <?php if(session('status')): ?>
                <div class="text-sm border border-t-8 rounded text-green-700 border-green-600 bg-green-100 px-3 py-4 mb-4" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <div class="flex flex-col break-words bg-white border rounded shadow-md">

                <div class="font-semibold bg-gray-200 text-gray-700 py-3 px-6 mb-0">
                    Olá, <?php echo e(auth()->user()->name); ?>

                </div>

                <div class="w-full p-6">
                    <p class="text-gray-700">
                        Bem vindo ao Clube do Livro!
                    </p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\clube-do-livro\resources\views/home.blade.php ENDPATH**/ ?>