<header class="bg-white shadow sticky top-0 z-50">
    <div class="max-w-7xl mx-auto py-3 sm:py-6 px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between">
            <h1 class="text-xl sm:text-3xl font-bold leading-tight text-gray-900 ">
                <?php echo e($slot); ?>

                <?php if(isset($subtitle)): ?>
                <?php echo e($subtitle); ?>

                <?php endif; ?>
            </h1>
            <?php if(isset($button)): ?>
            <?php echo e($button); ?>

            <?php endif; ?>
        </div>
    </div>
</header><?php /**PATH C:\wamp64\www\clube-do-livro\resources\views/components/header.blade.php ENDPATH**/ ?>