

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('elections.votes.store', $election)); ?>" method="POST">
    <?php echo csrf_field(); ?>

     <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        Votação
         <?php $__env->slot('button'); ?> 
             <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, []); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Votar <?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <main>
        <?php $__errorArgs = ['books'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <alert variation="danger"><?php echo e($message); ?></alert>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8 lg:grid grid-cols-3">
            <!-- Replace with your content -->
            <div class="align-middle inline-block min-w-full shadow overflow-x-auto sm:rounded-lg border-b border-gray-200 col-span-2">
                <table class="min-w-full">
                    <tbody class="bg-white">
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-yellow-50 odd:bg-gray-100">
                                <td class="px-6 py-4 border-b border-gray-200 text-base sm:text-sm">
                                    <div class="flex flex-col sm:flex-row justify-between">
                                        <span class="font-medium"><?php echo e($book->title); ?></span>
                                        <div class="mt-3 sm:mt-0">
                                            <label class="inline-flex items-center">
                                                <input type="radio" class="form-radio h-5 w-5 text-indigo-600 transition duration-150 ease-in-out cursor-pointer" name="books[<?php echo e($book->id); ?>]" value="0" checked>
                                                <span class="ml-1 md:ml-2 cursor-pointer text-xs sm:text-sm">0</span>
                                            </label>
                                            <label class="inline-flex items-center ml-3 md:ml-4">
                                                <input type="radio" class="form-radio h-5 w-5 text-indigo-600 transition duration-150 ease-in-out cursor-pointer" name="books[<?php echo e($book->id); ?>]" value="1" <?php if(!is_null(old('books')) && old('books')[$book->id] == '1'): ?> checked <?php endif; ?>>
                                                <span class="ml-1 md:ml-2 cursor-pointer text-xs sm:text-sm">1</span>
                                            </label>
                                            <label class="inline-flex items-center ml-3 md:ml-4">
                                                <input type="radio" class="form-radio h-5 w-5 text-indigo-600 transition duration-150 ease-in-out cursor-pointer" name="books[<?php echo e($book->id); ?>]" value="2" <?php if(!is_null(old('books')) && old('books')[$book->id] == '2'): ?> checked <?php endif; ?>>
                                                <span class="ml-1 md:ml-2 cursor-pointer text-xs sm:text-sm">2</span>
                                            </label>
                                            <label class="inline-flex items-center ml-3 md:ml-4">
                                                <input type="radio" class="form-radio h-5 w-5 text-indigo-600 transition duration-150 ease-in-out cursor-pointer" name="books[<?php echo e($book->id); ?>]" value="3" <?php if(!is_null(old('books')) && old('books')[$book->id] == '3'): ?> checked <?php endif; ?>>
                                                <span class="ml-1 md:ml-2 cursor-pointer text-xs sm:text-sm">3</span>
                                            </label>
                                            <label class="inline-flex items-center ml-3 md:ml-4">
                                                <input type="radio" class="form-radio h-5 w-5 text-indigo-600 transition duration-150 ease-in-out cursor-pointer" name="books[<?php echo e($book->id); ?>]" value="4" <?php if(!is_null(old('books')) && old('books')[$book->id] == '4'): ?> checked <?php endif; ?>>
                                                <span class="ml-1 md:ml-2 cursor-pointer text-xs sm:text-sm">4</span>
                                            </label>
                                            <label class="inline-flex items-center ml-3 md:ml-4">
                                                <input type="radio" class="form-radio h-5 w-5 text-indigo-600 transition duration-150 ease-in-out cursor-pointer" name="books[<?php echo e($book->id); ?>]" value="5" <?php if(!is_null(old('books')) && old('books')[$book->id] == '5'): ?> checked <?php endif; ?>>
                                                <span class="ml-1 md:ml-2 cursor-pointer text-xs sm:text-sm">5</span>
                                            </label>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- /End replace -->
    </main>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\clube-do-livro\resources\views/elections/votes/create.blade.php ENDPATH**/ ?>